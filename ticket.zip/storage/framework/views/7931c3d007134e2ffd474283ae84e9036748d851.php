<?php $__env->startSection('content'); ?>
<div class="main-panel ">
    <div class="main-content">
          <div class="content-wrapper">    
        
                <div class="card card-outline-info box-shadow-0 text-center"  >
                    <div class="card-content">
                    <div class="card-body pt-3">
                        <div class="row d-flex">
                            <div class="col-md-3 align-self-center">
                                <img src="<?php echo e(asset('images')); ?>/<?php echo e($data->image); ?>" alt="element 04" width="310" class="float-left mt-3">
                            </div>
                            <div class="col-md-6 ">
                                <h4 class="card-title mt-3"><?php echo e($data->name); ?></h4>
                                <p class="card-text"><?php echo e($data->description); ?></p>
                                <a href="<?php echo e(route('ticket.index')); ?>" class="btn btn-raised btn-info btn-darken-3">View all tickets</a>
                            </div>
                            <div class="col-md-3  ">
                                <p class="card-text">$ <?php echo e($data->price); ?></p>
                                <p class="card-text"><?php echo e($data->sale_date); ?></p>
                                <p class="card-text"><?php echo e($data->resale_date); ?></p>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>

         </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\XAMPP\htdocs\ticket\resources\views/ticketview.blade.php ENDPATH**/ ?>