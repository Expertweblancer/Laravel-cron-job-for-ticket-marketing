<!DOCTYPE html>
<html>
<head>
    <title>Ticket Business</title>
</head>
<body>
    <div class="">
        <div class="row">
            <div class="col-md-3">
                <img src="http://localhost:10085/img/ticket.png" alt="" width="20%">
            </div>
            <div class="col-md-3">
                <h1 style="font-family:cursive">Business Ticket</h1>
            </div>
        </div>
        <h2 style="font-family:cursive">Today Ticket Count: <?php echo e($data['count']); ?> ,Total Cost: $<?php echo e($data['price']); ?> </h2>
        <?php $__empty_1 = true; $__currentLoopData = $data['tickets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div>
                <h3 style="font-family:cursive"><?php echo e($ticket->name); ?></h3>
                <div class="">
                    <span style="font-family:cursive">Ticket Price: $<?php echo e($ticket->price); ?></span>,
                    <span style="font-family:cursive">Sales Date: <?php echo e($ticket->sale_date); ?></span>,
                    <span style="font-family:cursive">Resales Date: <?php echo e($ticket->resale_date); ?></span>
                    <p style="font-family:monospace"><?php echo e($ticket->description); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
 
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH F:\XAMPP\htdocs\ticket\resources\views/emails/ticketcount.blade.php ENDPATH**/ ?>