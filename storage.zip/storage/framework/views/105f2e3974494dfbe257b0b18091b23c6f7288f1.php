<div>
    Total number of registered users for today is: <?php echo e($count); ?>

</div><?php /**PATH F:\XAMPP\htdocs\ticket\resources\views/emails/registeredcount.blade.php ENDPATH**/ ?>